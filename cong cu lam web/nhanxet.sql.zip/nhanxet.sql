-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th9 15, 2018 lúc 09:49 AM
-- Phiên bản máy phục vụ: 10.1.31-MariaDB
-- Phiên bản PHP: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `danhsach`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhanxet`
--

CREATE TABLE `nhanxet` (
  `ID` int(11) NOT NULL,
  `Ten` text NOT NULL,
  `Sao` int(11) NOT NULL,
  `Nhanxet` text NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `nhanxet`
--

INSERT INTO `nhanxet` (`ID`, `Ten`, `Sao`, `Nhanxet`, `Date`) VALUES
(8, 'hao', 4, 'Không có thêm chi phí hàng tồn kho trước hoặc hậu cần vận chuyển. Sản phẩm được gửi trực tiếp từ người bán luôn cho khách hàng của bạn.Không có thêm chi phí hàng tồn kho trước hoặc hậu cần vận chuyển. Sản phẩm được gửi trực tiếp từ người bán buôn cho khách hàng của bạn.', '0000-00-00'),
(9, 'hao', 5, 'Không có thêm chi phí hàng tồn kho trước hoặc hậu cần vận chuyển. Sản phẩm được gửi trực tiếp từ người bán luôn cho khách hàng của bạn.Không có thêm chi phí hàng tồn kho trước hoặc hậu cần vận chuyển. Sản phẩm được gửi trực tiếp từ người bán buôn cho khách hàng của bạn.', '0000-00-00'),
(477, '01', 5, 'Không có thêm chi phí hàng tồn kho trước hoặc hậu cần vận chuyển. Sản phẩm được gửi trực tiếp từ người bán luôn cho khách hàng của bạn.Không có thêm chi phí hàng tồn kho trước hoặc hậu cần vận chuyển. Sản phẩm được gửi trực tiếp từ người bán buôn cho khách hàng của bạn.', '0000-00-00');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `nhanxet`
--
ALTER TABLE `nhanxet`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `nhanxet`
--
ALTER TABLE `nhanxet`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=515;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

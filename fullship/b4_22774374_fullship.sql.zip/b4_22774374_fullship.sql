-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Client: sql104.byethost.com
-- Généré le: Mar 13 Novembre 2018 à 07:32
-- Version du serveur: 5.6.41-84.1
-- Version de PHP: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `b4_22774374_fullship`
--

-- --------------------------------------------------------

--
-- Structure de la table `calamviec`
--

CREATE TABLE IF NOT EXISTS `calamviec` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MaNV` text NOT NULL,
  `TenNV` text NOT NULL,
  `C2S` smallint(6) NOT NULL,
  `C2C` smallint(6) NOT NULL,
  `C2T` smallint(6) NOT NULL,
  `C2PS` text NOT NULL,
  `C2PC` text NOT NULL,
  `C2PT` text NOT NULL,
  `C3S` smallint(6) NOT NULL,
  `C3C` smallint(6) NOT NULL,
  `C3T` smallint(6) NOT NULL,
  `C3PS` text NOT NULL,
  `C3PC` text NOT NULL,
  `C3PT` text NOT NULL,
  `C4S` smallint(6) NOT NULL,
  `C4C` smallint(6) NOT NULL,
  `C4T` smallint(6) NOT NULL,
  `C4PS` text NOT NULL,
  `C4PC` text NOT NULL,
  `C4PT` text NOT NULL,
  `C5S` smallint(6) NOT NULL,
  `C5C` smallint(6) NOT NULL,
  `C5T` smallint(6) NOT NULL,
  `C5PS` text NOT NULL,
  `C5PC` text NOT NULL,
  `C5PT` text NOT NULL,
  `C6S` smallint(6) NOT NULL,
  `C6C` smallint(6) NOT NULL,
  `C6T` smallint(6) NOT NULL,
  `C6PS` text NOT NULL,
  `C6PC` text NOT NULL,
  `C6PT` text NOT NULL,
  `C7S` smallint(6) NOT NULL,
  `C7C` smallint(6) NOT NULL,
  `C7T` smallint(6) NOT NULL,
  `C7PS` text NOT NULL,
  `C7PC` text NOT NULL,
  `C7PT` text NOT NULL,
  `C8S` smallint(6) NOT NULL,
  `C8C` smallint(6) NOT NULL,
  `C8T` smallint(6) NOT NULL,
  `C8PS` text NOT NULL,
  `C8PC` text NOT NULL,
  `C8PT` text NOT NULL,
  `DateGui` date NOT NULL,
  `Tuanhh` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=76 ;

--
-- Contenu de la table `calamviec`
--

INSERT INTO `calamviec` (`ID`, `MaNV`, `TenNV`, `C2S`, `C2C`, `C2T`, `C2PS`, `C2PC`, `C2PT`, `C3S`, `C3C`, `C3T`, `C3PS`, `C3PC`, `C3PT`, `C4S`, `C4C`, `C4T`, `C4PS`, `C4PC`, `C4PT`, `C5S`, `C5C`, `C5T`, `C5PS`, `C5PC`, `C5PT`, `C6S`, `C6C`, `C6T`, `C6PS`, `C6PC`, `C6PT`, `C7S`, `C7C`, `C7T`, `C7PS`, `C7PC`, `C7PT`, `C8S`, `C8C`, `C8T`, `C8PS`, `C8PC`, `C8PT`, `DateGui`, `Tuanhh`) VALUES
(28, 'Duy', 'Duy', 1, 0, 0, '', '', '', 1, 0, 0, '', '14h-16h', '', 0, 0, 0, '', '', '', 0, 1, 1, '', '', '', 0, 0, 1, '', '', '', 0, 1, 0, '', '', '', 1, 1, 0, '', '', '', '2018-10-10', '2018-10-2'),
(30, 'Hue.td', 'Nguyễn thị Huệ', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 1, 0, '', '', '', 0, 0, 1, '', '', '18_22', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', '2018-10-10', '2018-10-2'),
(62, 'Tanthien', 'Trần nguyễn tân thiện', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 1, 0, 0, '', '12h30 - 14h', '', 1, 1, 0, '', '', '', '2018-10-20', '2018-10-4'),
(64, 'Phuc.sp', 'Nguyễn hữu Phúc', 0, 0, 0, '', '12h-3h', '', 0, 0, 0, '', '', '', 0, 1, 0, '9:00-12:30', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 1, 0, 0, '', '', '', 0, 0, 0, '', '', '', '2018-10-20', '2018-10-4'),
(57, 'Vanchi', 'Trần văn chí', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', '2018-10-16', '2018-10-3'),
(55, 'Minhcanh', 'Nguyễn Minh Cảnh', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 1, 1, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 1, '', '', '', '2018-10-13', '2018-10-3'),
(54, 'Viet.sp', 'Nguyễn quốc việt', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 0, 1, 0, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', '2018-10-13', '2018-10-3'),
(58, 'Thinhan', 'Trần diệp thi nhân', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', 0, 0, 0, '', '', '', '2018-10-18', '2018-10-4'),
(59, 'tongdai1', 'tongdai1', 0, 1, 0, '', '', '', 1, 0, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 1, 1, 0, '', '', '', '2018-10-20', '2018-10-4'),
(51, 'Tanthien', 'Trần nguyễn tân thiện', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 1, '', '', '', 0, 0, 0, '', '', '19h-22h', 0, 0, 1, '10h30 -13h30', '', '', 1, 0, 0, '', '12h30-14h', '', 1, 1, 0, '', '', '', '2018-10-13', '2018-10-3'),
(47, 'Thinhan', 'Trần diệp thi nhân', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', '2018-10-12', '2018-10-3'),
(48, 'tongdai1', 'tongdai1', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 0, 1, 0, '', '', '', 1, 0, 0, '', '', '', '2018-10-12', '2018-10-3'),
(61, 'Minhcanh', 'Nguyễn Minh Cảnh', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 1, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 1, '', '', '', '2018-10-20', '2018-10-4'),
(50, 'Truong.sp', 'võ quang trường', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', '2018-10-13', '2018-10-3'),
(63, 'tongdai3', 'tongdai3', 0, 0, 0, '', '', '', 0, 0, 1, '', '', '', 1, 0, 0, '', '', '', 0, 0, 1, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 0, 0, 0, '', '', '', '2018-10-20', '2018-10-4'),
(65, 'Truong.sp', 'võ quang trường', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', '2018-10-20', '2018-10-4'),
(66, 'Viet.sp', 'Nguyễn quốc việt', 0, 1, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 0, 1, 0, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', '2018-10-20', '2018-10-4'),
(67, 'tongdai2', 'tongdai2', 1, 0, 1, '', '', '', 0, 1, 0, '', '', '', 0, 0, 1, '', '', '', 1, 0, 0, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', '2018-10-20', '2018-10-4'),
(75, 'Phuc.sp', 'Nguyễn hữu Phúc', 0, 0, 0, '', '12h-3h', '', 0, 0, 0, '', '', '', 0, 0, 0, '9:00-11h30', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', '2018-11-11', '2018-11-3'),
(69, 'Tanthien', 'Trần nguyễn tân thiện', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 0, 0, 1, '', '', '', 1, 1, 0, '', '', '', 1, 1, 0, '', '', '', '2018-10-27', '2018-11-1'),
(74, 'tongdai1', 'tongdai1', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', '2018-11-09', '2018-11-3'),
(71, 'Minhcanh', 'Nguyễn Minh Cảnh', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 1, '', '', '', 0, 0, 0, '', '', '', 0, 0, 0, '', '', '', 0, 0, 1, '', '', '', '2018-10-27', '2018-11-1'),
(73, 'tongdai1', 'tongdai1', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', 1, 0, 0, '', '', '', '2018-11-01', '2018-11-2');

-- --------------------------------------------------------

--
-- Structure de la table `chophep`
--

CREATE TABLE IF NOT EXISTS `chophep` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date NOT NULL,
  `MaNV` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `chophep`
--

INSERT INTO `chophep` (`ID`, `Date`, `MaNV`) VALUES
(7, '2018-01-01', 'Duy'),
(8, '2018-10-16', 'Duy'),
(9, '2018-10-16', 'Vanchi'),
(10, '2018-11-11', 'Phuc.sp');

-- --------------------------------------------------------

--
-- Structure de la table `donhang`
--

CREATE TABLE IF NOT EXISTS `donhang` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ca` smallint(6) NOT NULL,
  `Date` date NOT NULL,
  `MaNV` text NOT NULL,
  `MaDonHang` text NOT NULL,
  `GiaoHang` smallint(6) NOT NULL,
  `Price` int(11) NOT NULL,
  `MaTD` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=171 ;

--
-- Contenu de la table `donhang`
--

INSERT INTO `donhang` (`ID`, `Ca`, `Date`, `MaNV`, `MaDonHang`, `GiaoHang`, `Price`, `MaTD`) VALUES
(42, 1, '2018-10-08', 'Duy', '01', 1, 0, 'tongdai'),
(44, 1, '2018-10-09', 'Duy', '0910#001', 1, 0, 'tongdai'),
(45, 1, '2018-10-09', 'Duy', '0910#036', 1, 0, 'tongdai'),
(46, 1, '2018-10-09', 'Duy', '0910#078', 1, 0, 'tongdai'),
(47, 3, '2018-10-09', '456', '0910#099', 0, 0, 'tongdai'),
(48, 1, '2018-10-10', 'Duy', '1010#001', 1, 0, 'tongdai'),
(49, 2, '2018-10-10', 'Duy', '1010#099', 1, 12000, 'tongdai'),
(50, 1, '2018-10-10', 'Hue.td', '0910#036', 0, 20000, 'tongdai'),
(51, 2, '2018-10-10', 'Duy', '1010#100', 1, 15000, 'tongdai'),
(86, 1, '2018-10-18', 'Thinhan', '1810#002', 1, 30000, 'tongdai2'),
(81, 2, '2018-10-17', 'Vanchi', '1710#003 mua hàng', 1, 35000, 'tongdai1'),
(82, 1, '2018-10-18', 'Phuc.sp', '1810#001', 1, 15000, 'tongdai2'),
(87, 2, '2018-10-18', 'Minhcanh', '1810#003 MUA HÀNG', 0, 12000, 'tongdai1'),
(80, 2, '2018-10-17', 'Thinhan', '1710#002 mua hàng', 1, 12000, 'tongdai1'),
(79, 2, '2018-10-17', 'Vanchi', '1710#001 MUA HÀNG', 1, 24000, 'tongdai1'),
(77, 1, '2018-10-17', 'Thinhan', '1710#005', 1, 12000, 'tongdai2'),
(76, 1, '2018-10-17', 'Phuc.sp', '1710#004', 1, 17000, 'tongdai2'),
(75, 1, '2018-10-17', 'Phuc.sp', '1710#003', 1, 12000, 'tongdai2'),
(74, 1, '2018-10-17', 'Viet.sp', '1710#002', 1, 15000, 'tongdai2'),
(73, 1, '2018-10-17', 'Vanchi', '1710#001', 1, 12000, 'tongdai2'),
(88, 1, '2018-10-18', 'Tanthien', '1810#004', 1, 12000, 'tongdai2'),
(89, 1, '2018-10-18', 'Truong.sp', '1810#005', 1, 20000, 'tongdai2'),
(91, 1, '2018-10-19', 'Phuc.sp', '1910#001', 1, 17000, 'tongdai2'),
(92, 1, '2018-10-19', 'Tanthien', '1910#002', 1, 12000, 'tongdai2'),
(94, 3, '2018-10-19', 'Tanthien', '1910#003', 1, 12000, 'tongdai3'),
(95, 3, '2018-10-19', 'Tanthien', '1910#004', 1, 17000, 'tongdai3'),
(96, 3, '2018-10-19', 'Truong.sp', '1910#005', 1, 12000, 'tongdai3'),
(97, 1, '2018-10-20', 'Tanthien', '2010#001', 1, 17000, 'tongdai2'),
(98, 2, '2018-10-20', 'Tanthien', '2010#002 mua hàng', 1, 15000, 'tongdai1'),
(99, 2, '2018-10-20', 'Phuc.sp', '2010#003 mua hàng', 1, 35000, 'tongdai1'),
(100, 2, '2018-10-20', 'Viet.sp', '2010#004 mua hàng', 1, 12000, 'tongdai1'),
(101, 1, '2018-10-21', 'Tanthien', '2110#001 mua hàng', 1, 20000, 'tongdai1'),
(102, 1, '2018-10-21', 'Tanthien', '2110#002', 1, 25000, 'tongdai2'),
(103, 3, '2018-10-21', 'Tanthien', '2110#003', 1, 17000, 'tongdai3'),
(104, 3, '2018-10-21', 'Tanthien', '2110#004', 1, 20000, 'tongdai3'),
(105, 3, '2018-10-21', 'Minhcanh', '2110#005', 1, 12000, 'tongdai3'),
(106, 1, '2018-10-22', 'Minhcanh', '2210#001', 1, 17000, 'tongdai2'),
(107, 1, '2018-10-22', 'Phuc.sp', '2210#002', 1, 25000, 'tongdai2'),
(108, 2, '2018-10-22', 'Viet.sp', '2210#003 mua hang', 1, 12000, 'tongdai1'),
(109, 1, '2018-10-23', 'Viet.sp', '2310#001 mua hang', 1, 17000, 'tongdai1'),
(110, 1, '2018-10-23', 'Tanthien', '2310#10', 1, 12000, 'tongdai2'),
(111, 1, '2018-10-23', 'Tanthien', '2310#003', 1, 12000, 'tongdai2'),
(112, 1, '2018-10-23', 'Tanthien', '2310#004', 1, 12000, 'tongdai2'),
(113, 1, '2018-10-23', 'Tanthien', '2310#005', 1, 12000, 'tongdai2'),
(114, 3, '2018-10-23', 'Duy', '2310#006', 0, 12000, 'tongdai3'),
(115, 1, '2018-10-24', 'Truong.sp', '2410#001', 1, 12000, 'tongdai2'),
(116, 2, '2018-10-26', 'Tanthien', '2610#001 Mua hàng', 1, 12000, 'tongdai1'),
(117, 1, '2018-10-26', 'Tanthien', '2610#001', 1, 12000, 'tongdai2'),
(118, 2, '2018-10-27', 'Phuc.sp', '2710#001 giao hàng', 1, 25000, 'tongdai1'),
(119, 1, '2018-10-27', 'Phuc.sp', '2710#002', 1, 12000, 'tongdai2'),
(120, 1, '2018-10-28', 'Duy', '2810#001 mua hang', 1, 12000, 'tongdai1'),
(121, 1, '2018-10-28', 'Tanthien', '2810#002 mua hàng', 1, 12000, 'tongdai1'),
(124, 2, '2018-10-28', 'Tanthien', '2810#003 mua hàng', 1, 17000, 'tongdai1'),
(125, 1, '2018-10-28', 'Minhcanh', '2810#004', 1, 12000, 'tongdai2'),
(127, 2, '2018-10-29', 'Duy', '2910#007', 1, 17000, 'tongdai3'),
(128, 2, '2018-10-29', 'Duy', '2910#002', 1, 15000, 'tongdai3'),
(130, 2, '2018-10-29', 'Duy', '2910#003 mua hàng', 1, 12000, 'tongdai3'),
(132, 2, '2018-10-29', 'Duy', '2910#010 mua hàng', 1, 15000, 'tongdai3'),
(133, 2, '2018-10-29', 'Duy', '2910#011 mua hang', 0, 17000, 'tongdai3'),
(134, 3, '2018-10-29', 'Tanthien', '2910#011', 1, 12000, 'tongdai'),
(135, 3, '2018-10-29', 'Tanthien', '2910#015', 1, 12000, 'tongdai'),
(136, 3, '2018-10-29', 'Tanthien', '2910#016', 1, 15000, 'tongdai'),
(137, 3, '2018-10-29', 'Tanthien', '2910#017', 1, 15000, 'tongdai'),
(139, 3, '2018-10-29', 'Duy', '2910#013', 0, 17000, 'tongdai'),
(140, 1, '2018-10-30', 'Tanthien', '3010#001', 1, 12000, 'tongdai2'),
(141, 1, '2018-10-30', 'Tanthien', '3010#002', 1, 12000, 'tongdai2'),
(142, 2, '2018-10-30', 'Tanthien', '3010#007 ', 1, 12000, 'tongdai3'),
(143, 3, '2018-10-30', 'Tanthien', '3010#009', 1, 12000, 'tongdai'),
(144, 2, '2018-10-31', 'Tanthien', '3110#007', 1, 12000, 'tongdai3'),
(145, 2, '2018-10-31', 'Tanthien', '3110#008 mua hàng', 1, 12000, 'tongdai1'),
(146, 3, '2018-10-31', 'Tanthien', '3110#009', 1, 12000, 'tongdai'),
(147, 1, '2018-11-01', 'Tanthien', '111#007', 1, 22000, 'tongdai2'),
(148, 2, '2018-11-01', 'Tanthien', '0111#008 mua hàng', 1, 12000, 'tongdai1'),
(150, 1, '2018-11-02', 'Duy', '211#001', 0, 22000, 'tongdai2'),
(151, 1, '2018-11-03', 'Tanthien', '0311#001 mua hàng', 1, 12000, 'tongdai1'),
(152, 1, '2018-11-03', 'Tanthien', '0311#002 mua hàng', 1, 17000, 'tongdai1'),
(153, 1, '2018-11-04', 'Tanthien', '0411#001 mua hàng', 1, 12000, 'tongdai1'),
(154, 2, '2018-11-04', 'Tanthien', '0411#002 ', 1, 12000, 'tongdai3'),
(155, 1, '2018-11-05', 'Duy', '0511#001', 0, 12000, 'tongdai2'),
(156, 1, '2018-11-06', 'Tanthien', '0611#001 mua hàng', 0, 17000, 'tongdai1'),
(158, 1, '2018-11-06', 'Duy', '0611#002 mua hàng, giao hàng', 1, 22000, 'tongdai1'),
(162, 3, '2018-11-06', 'Tanthien', '0611#005', 1, 15000, 'tongdai'),
(161, 3, '2018-11-06', 'Tanthien', '0611#004', 1, 30000, 'tongdai'),
(163, 3, '2018-11-06', 'Tanthien', '0611#006', 1, 12000, 'tongdai'),
(164, 1, '2018-11-07', 'Tanthien', '0711#001 giao hàng', 1, 12000, 'tongdai1'),
(165, 1, '2018-11-08', 'Duy', '0811#001', 0, 17000, 'tongdai2'),
(167, 1, '2018-11-08', 'Duy', '0811#002', 0, 25000, 'tongdai2'),
(168, 1, '2018-11-09', 'Tanthien', '0911#001', 1, 38000, 'tongdai2'),
(169, 1, '2018-11-09', 'Tanthien', '0911#003', 1, 17000, ''),
(170, 2, '2018-11-12', 'Duy', '1211#001 lấy hàng', 0, 15000, 'tongdai1');

-- --------------------------------------------------------

--
-- Structure de la table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Tittle` text NOT NULL,
  `Noidung` text NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `event`
--

INSERT INTO `event` (`ID`, `Tittle`, `Noidung`, `Date`) VALUES
(3, 'Giảm Phí Ship', '<p><span style="color:#3498db"><span style="font-size:18px"><strong>Bạn sẽ được giảm&nbsp;ph&iacute; Ship khi:</strong></span></span></p>\r\n\r\n<p>-Vận chuyển nhiều hơn 5 đơn h&agrave;ng</p>\r\n\r\n<p>-Hợp t&aacute;c với ch&uacute;ng t&ocirc;i 5 lần giảm một đơn h&agrave;ng.</p>\r\n', '2018-09-29'),
(7, 'Giá Dịch Vụ', '<p style="text-align:center"><img alt="" Width="700" src="http://fullship.info/img/028.jpg" style="max-width:100%" /></p>\r\n', '2018-10-14');

-- --------------------------------------------------------

--
-- Structure de la table `luottruycap`
--

CREATE TABLE IF NOT EXISTS `luottruycap` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Day` int(11) NOT NULL,
  `Month` int(11) NOT NULL,
  `Year` int(11) NOT NULL,
  `Value` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=70 ;

--
-- Contenu de la table `luottruycap`
--

INSERT INTO `luottruycap` (`ID`, `Day`, `Month`, `Year`, `Value`) VALUES
(22, 25, 9, 2018, 25),
(21, 24, 9, 2018, 14),
(20, 23, 9, 2018, 16),
(19, 22, 9, 2018, 11),
(18, 21, 9, 2018, 13),
(17, 20, 9, 2018, 36),
(16, 19, 9, 2018, 35),
(15, 18, 9, 2018, 59),
(14, 17, 9, 2018, 27),
(23, 26, 9, 2018, 34),
(24, 29, 9, 2018, 45),
(25, 30, 9, 2018, 22),
(26, 1, 10, 2018, 9),
(27, 2, 10, 2018, 4),
(28, 3, 10, 2018, 16),
(29, 4, 10, 2018, 19),
(30, 5, 10, 2018, 17),
(31, 6, 10, 2018, 3),
(32, 7, 10, 2018, 3),
(33, 8, 10, 2018, 34),
(34, 9, 10, 2018, 32),
(35, 10, 10, 2018, 52),
(36, 11, 10, 2018, 93),
(37, 12, 10, 2018, 26),
(38, 13, 10, 2018, 31),
(39, 14, 10, 2018, 38),
(40, 15, 10, 2018, 24),
(41, 16, 10, 2018, 22),
(42, 17, 10, 2018, 54),
(43, 18, 10, 2018, 48),
(44, 19, 10, 2018, 31),
(45, 20, 10, 2018, 42),
(46, 21, 10, 2018, 29),
(47, 22, 10, 2018, 30),
(48, 23, 10, 2018, 24),
(49, 24, 10, 2018, 19),
(50, 25, 10, 2018, 13),
(51, 26, 10, 2018, 19),
(52, 27, 10, 2018, 25),
(53, 28, 10, 2018, 26),
(54, 29, 10, 2018, 19),
(55, 30, 10, 2018, 17),
(56, 31, 10, 2018, 22),
(57, 1, 11, 2018, 14),
(58, 2, 11, 2018, 19),
(59, 3, 11, 2018, 8),
(60, 4, 11, 2018, 12),
(61, 5, 11, 2018, 12),
(62, 6, 11, 2018, 10),
(63, 7, 11, 2018, 4),
(64, 8, 11, 2018, 11),
(65, 9, 11, 2018, 16),
(66, 10, 11, 2018, 5),
(67, 11, 11, 2018, 15),
(68, 12, 11, 2018, 11),
(69, 13, 11, 2018, 4);

-- --------------------------------------------------------

--
-- Structure de la table `nhanxet`
--

CREATE TABLE IF NOT EXISTS `nhanxet` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ten` text NOT NULL,
  `Sao` int(11) NOT NULL,
  `Nhanxet` text NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `nhanxet`
--

INSERT INTO `nhanxet` (`ID`, `Ten`, `Sao`, `Nhanxet`, `Date`) VALUES
(10, 'Duy', 5, 'Dich vu rât mới va tốt.. may a shipper thi rat de thuong', '2018-09-30');

-- --------------------------------------------------------

--
-- Structure de la table `thongtin`
--

CREATE TABLE IF NOT EXISTS `thongtin` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `usename` text NOT NULL,
  `password` text NOT NULL,
  `HoTenDem` text NOT NULL,
  `Ten` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Contenu de la table `thongtin`
--

INSERT INTO `thongtin` (`ID`, `usename`, `password`, `HoTenDem`, `Ten`) VALUES
(1, 'admin', '@2018@', '', 'Admin'),
(8, 'tongdai', '123456', '', 'Tổng Đài'),
(22, 'Duy', '12345', '', 'Duy'),
(11, 'tongdai1', 'DinhBao24316', '', 'tongdai1'),
(12, 'tongdai2', 'nhapdaidi098', '', 'tongdai2'),
(14, 'tongdai4', 'FULLSHIPVL', '', 'tongdai4'),
(15, 'tongdai5', 'FULLSHIPVL', '', 'tongdai5'),
(16, 'tongdai6', 'FULLSHIPVL', '', 'tongdai6'),
(35, 'Phuc.sp', '133100Aa', '', 'Nguyễn hữu Phúc');

-- --------------------------------------------------------

--
-- Structure de la table `tuanhh`
--

CREATE TABLE IF NOT EXISTS `tuanhh` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Start` date NOT NULL,
  `End` date NOT NULL,
  `Tuanhh` text NOT NULL,
  `Tuan` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `tuanhh`
--

INSERT INTO `tuanhh` (`ID`, `Start`, `End`, `Tuanhh`, `Tuan`) VALUES
(11, '2018-10-08', '2018-10-14', '2018-10', 2),
(10, '2018-10-01', '2018-10-07', '2018-10', 1),
(12, '2018-10-15', '2018-10-21', '2018-10', 3),
(13, '2018-10-22', '2018-10-28', '2018-10', 4),
(14, '2018-10-29', '2018-11-04', '2018-11', 1),
(15, '2018-11-05', '2018-11-11', '2018-11', 2),
(16, '2018-11-12', '2018-11-18', '2018-11', 3);

-- --------------------------------------------------------

--
-- Structure de la table `ungtuyen`
--

CREATE TABLE IF NOT EXISTS `ungtuyen` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ten` text NOT NULL,
  `Tuoi` int(11) NOT NULL,
  `Trinhdo` text CHARACTER SET utf8mb4 NOT NULL,
  `SDT` text NOT NULL,
  `Place` text NOT NULL,
  `Gioithieu` text NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `ungtuyen`
--

INSERT INTO `ungtuyen` (`ID`, `Ten`, `Tuoi`, `Trinhdo`, `SDT`, `Place`, `Gioithieu`, `Date`) VALUES
(9, 'Tiền', 26, '12', '0768899012', 'Vĩnh Long', '<p>Đang học đại học x&acirc;y dựng miền t&acirc;y, m&igrave;nh muốn kiếm th&ecirc;m thu nhập trang trải việc học, ph&ugrave; hợp theo lich học</p>\r\n', '2018-10-17'),
(10, 'Nguyễn Ngọc Lài ', 21, 'Cao Đẳng', '0907138523', 'Đồng Tháp', '<p>Tốt nghiệp cao đẳng chuy&ecirc;n ng&agrave;nh kế to&aacute;n, mong muốn t&igrave;m kiếm được một c&ocirc;ng việc ổn định với mức lương ph&ugrave; hợp&nbsp;</p>\r\n', '2018-10-17');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
